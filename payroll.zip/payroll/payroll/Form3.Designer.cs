﻿namespace payroll
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpLeaveApproval = new GroupBox();
            label1 = new Label();
            label2 = new Label();
            cmbEmployee = new ComboBox();
            button1 = new Button();
            cmbStatus = new ComboBox();
            dgvLeaveRequests = new DataGridView();
            grpApprovalDetails = new GroupBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            dtpApprovalDate = new DateTimePicker();
            cmbApprovedBy = new ComboBox();
            rtbComments = new RichTextBox();
            btnApprove = new Button();
            btnReject = new Button();
            btnClear = new Button();
            grpLeaveApproval.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLeaveRequests).BeginInit();
            grpApprovalDetails.SuspendLayout();
            SuspendLayout();
            // 
            // grpLeaveApproval
            // 
            grpLeaveApproval.Controls.Add(dgvLeaveRequests);
            grpLeaveApproval.Controls.Add(cmbStatus);
            grpLeaveApproval.Controls.Add(button1);
            grpLeaveApproval.Controls.Add(cmbEmployee);
            grpLeaveApproval.Controls.Add(label2);
            grpLeaveApproval.Controls.Add(label1);
            grpLeaveApproval.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            grpLeaveApproval.ForeColor = Color.DarkBlue;
            grpLeaveApproval.Location = new Point(12, 12);
            grpLeaveApproval.Name = "grpLeaveApproval";
            grpLeaveApproval.Size = new Size(956, 284);
            grpLeaveApproval.TabIndex = 0;
            grpLeaveApproval.TabStop = false;
            grpLeaveApproval.Text = " Leave Approval";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(0, 42);
            label1.Name = "label1";
            label1.Size = new Size(61, 20);
            label1.TabIndex = 0;
            label1.Text = "Status :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(363, 42);
            label2.Name = "label2";
            label2.Size = new Size(85, 20);
            label2.TabIndex = 1;
            label2.Text = "Employee :";
            // 
            // cmbEmployee
            // 
            cmbEmployee.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbEmployee.FormattingEnabled = true;
            cmbEmployee.Location = new Point(468, 37);
            cmbEmployee.Name = "cmbEmployee";
            cmbEmployee.Size = new Size(263, 31);
            cmbEmployee.TabIndex = 3;
            // 
            // button1
            // 
            button1.BackColor = Color.Blue;
            button1.ForeColor = Color.White;
            button1.Location = new Point(794, 28);
            button1.Name = "button1";
            button1.Size = new Size(121, 46);
            button1.TabIndex = 4;
            button1.Text = "Load";
            button1.UseVisualStyleBackColor = false;
            // 
            // cmbStatus
            // 
            cmbStatus.FormattingEnabled = true;
            cmbStatus.Location = new Point(67, 35);
            cmbStatus.Name = "cmbStatus";
            cmbStatus.Size = new Size(230, 31);
            cmbStatus.TabIndex = 1;
            // 
            // dgvLeaveRequests
            // 
            dgvLeaveRequests.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvLeaveRequests.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvLeaveRequests.Location = new Point(0, 88);
            dgvLeaveRequests.Name = "dgvLeaveRequests";
            dgvLeaveRequests.ReadOnly = true;
            dgvLeaveRequests.RowHeadersWidth = 51;
            dgvLeaveRequests.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvLeaveRequests.Size = new Size(946, 196);
            dgvLeaveRequests.TabIndex = 5;
            // 
            // grpApprovalDetails
            // 
            grpApprovalDetails.Controls.Add(btnClear);
            grpApprovalDetails.Controls.Add(btnReject);
            grpApprovalDetails.Controls.Add(btnApprove);
            grpApprovalDetails.Controls.Add(rtbComments);
            grpApprovalDetails.Controls.Add(cmbApprovedBy);
            grpApprovalDetails.Controls.Add(dtpApprovalDate);
            grpApprovalDetails.Controls.Add(label5);
            grpApprovalDetails.Controls.Add(label4);
            grpApprovalDetails.Controls.Add(label3);
            grpApprovalDetails.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            grpApprovalDetails.ForeColor = Color.DarkBlue;
            grpApprovalDetails.Location = new Point(12, 318);
            grpApprovalDetails.Name = "grpApprovalDetails";
            grpApprovalDetails.Size = new Size(902, 239);
            grpApprovalDetails.TabIndex = 1;
            grpApprovalDetails.TabStop = false;
            grpApprovalDetails.Text = "Approval Details";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(20, 39);
            label3.Name = "label3";
            label3.Size = new Size(108, 20);
            label3.TabIndex = 0;
            label3.Text = "Approved By :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(485, 33);
            label4.Name = "label4";
            label4.Size = new Size(118, 20);
            label4.TabIndex = 1;
            label4.Text = "Approval Date :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(20, 96);
            label5.Name = "label5";
            label5.Size = new Size(93, 20);
            label5.TabIndex = 2;
            label5.Text = "Comments :";
            // 
            // dtpApprovalDate
            // 
            dtpApprovalDate.Format = DateTimePickerFormat.Short;
            dtpApprovalDate.Location = new Point(622, 29);
            dtpApprovalDate.Name = "dtpApprovalDate";
            dtpApprovalDate.Size = new Size(250, 30);
            dtpApprovalDate.TabIndex = 3;
            // 
            // cmbApprovedBy
            // 
            cmbApprovedBy.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbApprovedBy.FormattingEnabled = true;
            cmbApprovedBy.Location = new Point(168, 32);
            cmbApprovedBy.Name = "cmbApprovedBy";
            cmbApprovedBy.Size = new Size(236, 31);
            cmbApprovedBy.TabIndex = 4;
            // 
            // rtbComments
            // 
            rtbComments.Location = new Point(168, 80);
            rtbComments.Name = "rtbComments";
            rtbComments.Size = new Size(704, 85);
            rtbComments.TabIndex = 5;
            rtbComments.Text = "";
            // 
            // btnApprove
            // 
            btnApprove.BackColor = Color.DarkGreen;
            btnApprove.ForeColor = Color.White;
            btnApprove.Location = new Point(181, 179);
            btnApprove.Name = "btnApprove";
            btnApprove.Size = new Size(129, 45);
            btnApprove.TabIndex = 6;
            btnApprove.Text = "Approve";
            btnApprove.UseVisualStyleBackColor = false;
            // 
            // btnReject
            // 
            btnReject.BackColor = Color.Red;
            btnReject.ForeColor = Color.White;
            btnReject.Location = new Point(449, 179);
            btnReject.Name = "btnReject";
            btnReject.Size = new Size(127, 45);
            btnReject.TabIndex = 7;
            btnReject.Text = "Reject";
            btnReject.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = SystemColors.ControlLight;
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(686, 179);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(127, 45);
            btnClear.TabIndex = 8;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(965, 589);
            Controls.Add(grpApprovalDetails);
            Controls.Add(grpLeaveApproval);
            Name = "Form3";
            Text = "Leave Approval Form";
            grpLeaveApproval.ResumeLayout(false);
            grpLeaveApproval.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvLeaveRequests).EndInit();
            grpApprovalDetails.ResumeLayout(false);
            grpApprovalDetails.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox grpLeaveApproval;
        private Button button1;
        private ComboBox cmbEmployee;
        private Label label2;
        private Label label1;
        private ComboBox cmbStatus;
        private DataGridView dgvLeaveRequests;
        private GroupBox grpApprovalDetails;
        private Button btnClear;
        private Button btnReject;
        private Button btnApprove;
        private RichTextBox rtbComments;
        private ComboBox cmbApprovedBy;
        private DateTimePicker dtpApprovalDate;
        private Label label5;
        private Label label4;
        private Label label3;
    }
}