﻿namespace payroll
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtEmpID = new TextBox();
            txtEmpName = new TextBox();
            txtDepartment = new TextBox();
            groupBox2 = new GroupBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtAnnual = new TextBox();
            txtMedical = new TextBox();
            txtCasual = new TextBox();
            groupBox3 = new GroupBox();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            cmbLeaveType = new ComboBox();
            dtpToDate = new DateTimePicker();
            dtpFromDate = new DateTimePicker();
            txtNoDays = new TextBox();
            btnSubmit = new Button();
            btnClear = new Button();
            rtbReason = new RichTextBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtDepartment);
            groupBox1.Controls.Add(txtEmpName);
            groupBox1.Controls.Add(txtEmpID);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.DarkBlue;
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(450, 175);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Leave Information";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(9, 34);
            label1.Name = "label1";
            label1.Size = new Size(105, 20);
            label1.TabIndex = 0;
            label1.Text = "Employee ID :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(6, 84);
            label2.Name = "label2";
            label2.Size = new Size(131, 20);
            label2.TabIndex = 1;
            label2.Text = "Employee Name :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(9, 135);
            label3.Name = "label3";
            label3.Size = new Size(102, 20);
            label3.TabIndex = 2;
            label3.Text = "Department :";
            // 
            // txtEmpID
            // 
            txtEmpID.Location = new Point(175, 34);
            txtEmpID.Name = "txtEmpID";
            txtEmpID.Size = new Size(239, 30);
            txtEmpID.TabIndex = 3;
            // 
            // txtEmpName
            // 
            txtEmpName.Location = new Point(175, 79);
            txtEmpName.Name = "txtEmpName";
            txtEmpName.Size = new Size(239, 30);
            txtEmpName.TabIndex = 4;
            // 
            // txtDepartment
            // 
            txtDepartment.Location = new Point(175, 130);
            txtDepartment.Name = "txtDepartment";
            txtDepartment.Size = new Size(239, 30);
            txtDepartment.TabIndex = 5;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(txtCasual);
            groupBox2.Controls.Add(txtMedical);
            groupBox2.Controls.Add(txtAnnual);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label4);
            groupBox2.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.ForeColor = Color.DarkBlue;
            groupBox2.Location = new Point(531, 24);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(367, 163);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Leave Balance";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(15, 39);
            label4.Name = "label4";
            label4.Size = new Size(111, 20);
            label4.TabIndex = 0;
            label4.Text = "Annual Leave :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(15, 80);
            label5.Name = "label5";
            label5.Size = new Size(115, 20);
            label5.TabIndex = 1;
            label5.Text = "Medical Leave :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Black;
            label6.Location = new Point(24, 123);
            label6.Name = "label6";
            label6.Size = new Size(106, 20);
            label6.TabIndex = 2;
            label6.Text = "Casual Leave :";
            // 
            // txtAnnual
            // 
            txtAnnual.Location = new Point(166, 34);
            txtAnnual.Name = "txtAnnual";
            txtAnnual.Size = new Size(125, 30);
            txtAnnual.TabIndex = 3;
            // 
            // txtMedical
            // 
            txtMedical.Location = new Point(166, 80);
            txtMedical.Name = "txtMedical";
            txtMedical.Size = new Size(125, 30);
            txtMedical.TabIndex = 4;
            // 
            // txtCasual
            // 
            txtCasual.Location = new Point(166, 123);
            txtCasual.Name = "txtCasual";
            txtCasual.Size = new Size(125, 30);
            txtCasual.TabIndex = 5;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btnSubmit);
            groupBox3.Controls.Add(btnClear);
            groupBox3.Controls.Add(rtbReason);
            groupBox3.Controls.Add(txtNoDays);
            groupBox3.Controls.Add(dtpFromDate);
            groupBox3.Controls.Add(dtpToDate);
            groupBox3.Controls.Add(cmbLeaveType);
            groupBox3.Controls.Add(label11);
            groupBox3.Controls.Add(label10);
            groupBox3.Controls.Add(label9);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(label7);
            groupBox3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox3.ForeColor = Color.DarkBlue;
            groupBox3.Location = new Point(31, 231);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(867, 362);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Leave Details";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Black;
            label7.Location = new Point(6, 39);
            label7.Name = "label7";
            label7.Size = new Size(94, 20);
            label7.TabIndex = 0;
            label7.Text = "Leave Type :";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(486, 49);
            label8.Name = "label8";
            label8.Size = new Size(71, 20);
            label8.TabIndex = 1;
            label8.Text = "To Date :";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(15, 164);
            label9.Name = "label9";
            label9.Size = new Size(68, 20);
            label9.TabIndex = 2;
            label9.Text = "Reason :";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(6, 93);
            label10.Name = "label10";
            label10.Size = new Size(91, 20);
            label10.TabIndex = 3;
            label10.Text = "From Date :";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.Black;
            label11.Location = new Point(486, 108);
            label11.Name = "label11";
            label11.Size = new Size(99, 20);
            label11.TabIndex = 4;
            label11.Text = "No. of Days :";
            // 
            // cmbLeaveType
            // 
            cmbLeaveType.FormattingEnabled = true;
            cmbLeaveType.Location = new Point(134, 34);
            cmbLeaveType.Name = "cmbLeaveType";
            cmbLeaveType.Size = new Size(297, 31);
            cmbLeaveType.TabIndex = 5;
            // 
            // dtpToDate
            // 
            dtpToDate.Location = new Point(602, 41);
            dtpToDate.Name = "dtpToDate";
            dtpToDate.Size = new Size(250, 30);
            dtpToDate.TabIndex = 6;
            // 
            // dtpFromDate
            // 
            dtpFromDate.Location = new Point(134, 93);
            dtpFromDate.Name = "dtpFromDate";
            dtpFromDate.Size = new Size(297, 30);
            dtpFromDate.TabIndex = 7;
            // 
            // txtNoDays
            // 
            txtNoDays.Location = new Point(602, 103);
            txtNoDays.Name = "txtNoDays";
            txtNoDays.Size = new Size(250, 30);
            txtNoDays.TabIndex = 8;
            // 
            // btnSubmit
            // 
            btnSubmit.BackColor = Color.SeaGreen;
            btnSubmit.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSubmit.ForeColor = Color.White;
            btnSubmit.Location = new Point(337, 303);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(131, 44);
            btnSubmit.TabIndex = 3;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = SystemColors.ControlLight;
            btnClear.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(631, 303);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(137, 44);
            btnClear.TabIndex = 4;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // rtbReason
            // 
            rtbReason.Location = new Point(134, 159);
            rtbReason.Name = "rtbReason";
            rtbReason.Size = new Size(718, 115);
            rtbReason.TabIndex = 9;
            rtbReason.Text = "";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(910, 605);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form2";
            Text = "Leave Application Form";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox txtDepartment;
        private TextBox txtEmpName;
        private TextBox txtEmpID;
        private Label label3;
        private Label label2;
        private Label label1;
        private GroupBox groupBox2;
        private TextBox txtCasual;
        private TextBox txtMedical;
        private TextBox txtAnnual;
        private Label label6;
        private Label label5;
        private Label label4;
        private GroupBox groupBox3;
        private TextBox txtNoDays;
        private DateTimePicker dtpFromDate;
        private DateTimePicker dtpToDate;
        private ComboBox cmbLeaveType;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Button btnSubmit;
        private Button btnClear;
        private RichTextBox rtbReason;
    }
}