﻿namespace payroll
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            btnDashboard = new Button();
            btnEmployees = new Button();
            btnAttendance = new Button();
            btnLeave = new Button();
            btnPayroll = new Button();
            btnDepartments = new Button();
            btnReports = new Button();
            btnSettings = new Button();
            pnlmenu = new Panel();
            btnNotification = new Button();
            label2 = new Label();
            pictureBox2 = new PictureBox();
            btnLogout = new Button();
            panel1 = new Panel();
            label4 = new Label();
            panel4 = new Panel();
            panel10 = new Panel();
            label6 = new Label();
            label5 = new Label();
            panel9 = new Panel();
            lblMonth = new Label();
            lblMonthPayroll = new Label();
            label3 = new Label();
            panel7 = new Panel();
            label20 = new Label();
            label19 = new Label();
            panel8 = new Panel();
            panel6 = new Panel();
            lblPresentCount = new Label();
            lblPresent = new Label();
            panel5 = new Panel();
            lblTotalEmployeesCount = new Label();
            lblTotalEmployeesTitle = new Label();
            panel3 = new Panel();
            lblDate = new Label();
            lnkViewAll = new LinkLabel();
            dgvActivities = new DataGridView();
            label7 = new Label();
            label9 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlmenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            panel4.SuspendLayout();
            panel10.SuspendLayout();
            panel9.SuspendLayout();
            panel7.SuspendLayout();
            panel6.SuspendLayout();
            panel5.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvActivities).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkBlue;
            panel2.Location = new Point(253, 747);
            panel2.Name = "panel2";
            panel2.Size = new Size(990, 82);
            panel2.TabIndex = 3;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 50);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(68, 22);
            label1.Name = "label1";
            label1.Size = new Size(179, 40);
            label1.TabIndex = 1;
            label1.Text = "HR & PAYROLL\nMANAGEMENT SYSTEM";
            // 
            // btnDashboard
            // 
            btnDashboard.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDashboard.ForeColor = Color.Black;
            btnDashboard.Location = new Point(24, 92);
            btnDashboard.Name = "btnDashboard";
            btnDashboard.Size = new Size(180, 41);
            btnDashboard.TabIndex = 2;
            btnDashboard.Text = "🏠 Dashboard";
            btnDashboard.UseVisualStyleBackColor = true;
            btnDashboard.Click += btnDashboard_Click;
            // 
            // btnEmployees
            // 
            btnEmployees.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEmployees.Location = new Point(24, 160);
            btnEmployees.Name = "btnEmployees";
            btnEmployees.Size = new Size(180, 40);
            btnEmployees.TabIndex = 3;
            btnEmployees.Text = "👥 Employees";
            btnEmployees.UseVisualStyleBackColor = true;
            // 
            // btnAttendance
            // 
            btnAttendance.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAttendance.Location = new Point(24, 230);
            btnAttendance.Name = "btnAttendance";
            btnAttendance.Size = new Size(180, 39);
            btnAttendance.TabIndex = 4;
            btnAttendance.Text = "🕒 Attendance";
            btnAttendance.UseVisualStyleBackColor = true;
            // 
            // btnLeave
            // 
            btnLeave.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLeave.Location = new Point(24, 301);
            btnLeave.Name = "btnLeave";
            btnLeave.Size = new Size(180, 40);
            btnLeave.TabIndex = 5;
            btnLeave.Text = "📝 Leave";
            btnLeave.UseVisualStyleBackColor = true;
            // 
            // btnPayroll
            // 
            btnPayroll.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPayroll.Location = new Point(24, 370);
            btnPayroll.Name = "btnPayroll";
            btnPayroll.Size = new Size(180, 39);
            btnPayroll.TabIndex = 6;
            btnPayroll.Text = "💰 Payroll";
            btnPayroll.UseVisualStyleBackColor = true;
            // 
            // btnDepartments
            // 
            btnDepartments.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDepartments.Location = new Point(24, 438);
            btnDepartments.Name = "btnDepartments";
            btnDepartments.Size = new Size(180, 44);
            btnDepartments.TabIndex = 7;
            btnDepartments.Text = "🏢 Departments";
            btnDepartments.UseVisualStyleBackColor = true;
            // 
            // btnReports
            // 
            btnReports.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReports.Location = new Point(24, 509);
            btnReports.Name = "btnReports";
            btnReports.Size = new Size(180, 40);
            btnReports.TabIndex = 8;
            btnReports.Text = "📊 Reports";
            btnReports.UseVisualStyleBackColor = true;
            // 
            // btnSettings
            // 
            btnSettings.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSettings.Location = new Point(24, 578);
            btnSettings.Name = "btnSettings";
            btnSettings.Size = new Size(180, 42);
            btnSettings.TabIndex = 9;
            btnSettings.Text = "⚙️ Settings";
            btnSettings.UseVisualStyleBackColor = true;
            btnSettings.Click += btnSettings_Click;
            // 
            // pnlmenu
            // 
            pnlmenu.BackColor = Color.DarkBlue;
            pnlmenu.Controls.Add(btnSettings);
            pnlmenu.Controls.Add(btnReports);
            pnlmenu.Controls.Add(btnDepartments);
            pnlmenu.Controls.Add(btnPayroll);
            pnlmenu.Controls.Add(btnLeave);
            pnlmenu.Controls.Add(btnAttendance);
            pnlmenu.Controls.Add(btnEmployees);
            pnlmenu.Controls.Add(btnDashboard);
            pnlmenu.Controls.Add(label1);
            pnlmenu.Controls.Add(pictureBox1);
            pnlmenu.Dock = DockStyle.Left;
            pnlmenu.Location = new Point(0, 0);
            pnlmenu.Name = "pnlmenu";
            pnlmenu.Size = new Size(256, 853);
            pnlmenu.TabIndex = 0;
            pnlmenu.Paint += panel1_Paint;
            // 
            // btnNotification
            // 
            btnNotification.AutoSize = true;
            btnNotification.FlatStyle = FlatStyle.Flat;
            btnNotification.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnNotification.ForeColor = Color.White;
            btnNotification.Location = new Point(506, 12);
            btnNotification.Name = "btnNotification";
            btnNotification.Size = new Size(67, 49);
            btnNotification.TabIndex = 0;
            btnNotification.Text = "🔔";
            btnNotification.UseVisualStyleBackColor = true;
            btnNotification.Click += btnNotification_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.White;
            label2.Location = new Point(699, 12);
            label2.Name = "label2";
            label2.Size = new Size(98, 40);
            label2.TabIndex = 2;
            label2.Text = "John Doe\nHR Executive";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(629, 11);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(50, 50);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // btnLogout
            // 
            btnLogout.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogout.ForeColor = Color.Black;
            btnLogout.Location = new Point(854, 12);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(107, 40);
            btnLogout.TabIndex = 3;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkBlue;
            panel1.Controls.Add(btnLogout);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(btnNotification);
            panel1.Location = new Point(253, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1051, 70);
            panel1.TabIndex = 1;
            panel1.Paint += panel1_Paint_1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(9, 5);
            label4.Name = "label4";
            label4.Size = new Size(275, 41);
            label4.TabIndex = 1;
            label4.Text = "Welcome , Admin!";
            // 
            // panel4
            // 
            panel4.BackColor = Color.White;
            panel4.Controls.Add(panel10);
            panel4.Controls.Add(panel9);
            panel4.Controls.Add(panel7);
            panel4.Controls.Add(panel6);
            panel4.Controls.Add(panel5);
            panel4.Location = new Point(0, 69);
            panel4.Name = "panel4";
            panel4.Size = new Size(1048, 116);
            panel4.TabIndex = 3;
            // 
            // panel10
            // 
            panel10.BackColor = Color.SaddleBrown;
            panel10.Controls.Add(label6);
            panel10.Controls.Add(label5);
            panel10.Location = new Point(868, 0);
            panel10.Name = "panel10";
            panel10.Size = new Size(159, 118);
            panel10.TabIndex = 13;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(34, 50);
            label6.Name = "label6";
            label6.Size = new Size(99, 41);
            label6.TabIndex = 1;
            label6.Text = "🏬 05";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(14, 11);
            label5.Name = "label5";
            label5.Size = new Size(136, 28);
            label5.TabIndex = 0;
            label5.Text = "Departments";
            // 
            // panel9
            // 
            panel9.BackColor = Color.DarkViolet;
            panel9.Controls.Add(lblMonth);
            panel9.Controls.Add(lblMonthPayroll);
            panel9.Controls.Add(label3);
            panel9.Location = new Point(668, 0);
            panel9.Name = "panel9";
            panel9.Size = new Size(162, 118);
            panel9.TabIndex = 12;
            // 
            // lblMonth
            // 
            lblMonth.AutoSize = true;
            lblMonth.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMonth.ForeColor = Color.Black;
            lblMonth.Location = new Point(24, 39);
            lblMonth.Name = "lblMonth";
            lblMonth.Size = new Size(105, 28);
            lblMonth.TabIndex = 2;
            lblMonth.Text = "June 2026";
            // 
            // lblMonthPayroll
            // 
            lblMonthPayroll.AutoSize = true;
            lblMonthPayroll.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMonthPayroll.ForeColor = Color.White;
            lblMonthPayroll.Location = new Point(3, 67);
            lblMonthPayroll.Name = "lblMonthPayroll";
            lblMonthPayroll.Size = new Size(148, 28);
            lblMonthPayroll.TabIndex = 1;
            lblMonthPayroll.Text = "LKR 124,500.00";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.White;
            label3.Location = new Point(0, 11);
            label3.Name = "label3";
            label3.Size = new Size(164, 28);
            label3.TabIndex = 0;
            label3.Text = "Monthly Payroll";
            // 
            // panel7
            // 
            panel7.BackColor = Color.DarkOrange;
            panel7.Controls.Add(label20);
            panel7.Controls.Add(label19);
            panel7.Controls.Add(panel8);
            panel7.Location = new Point(460, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(172, 118);
            panel7.TabIndex = 11;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.ForeColor = Color.White;
            label20.Location = new Point(32, 50);
            label20.Name = "label20";
            label20.Size = new Size(102, 40);
            label20.TabIndex = 2;
            label20.Text = "📅 15";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label19.ForeColor = Color.White;
            label19.Location = new Point(16, 11);
            label19.Name = "label19";
            label19.Size = new Size(148, 28);
            label19.TabIndex = 1;
            label19.Text = "Pending Leave";
            // 
            // panel8
            // 
            panel8.Location = new Point(219, 0);
            panel8.Name = "panel8";
            panel8.Size = new Size(104, 142);
            panel8.TabIndex = 0;
            // 
            // panel6
            // 
            panel6.BackColor = Color.ForestGreen;
            panel6.Controls.Add(lblPresentCount);
            panel6.Controls.Add(lblPresent);
            panel6.Location = new Point(245, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(177, 118);
            panel6.TabIndex = 10;
            // 
            // lblPresentCount
            // 
            lblPresentCount.AutoSize = true;
            lblPresentCount.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPresentCount.ForeColor = Color.White;
            lblPresentCount.Location = new Point(28, 47);
            lblPresentCount.Name = "lblPresentCount";
            lblPresentCount.Size = new Size(102, 40);
            lblPresentCount.TabIndex = 1;
            lblPresentCount.Text = "📅 35";
            // 
            // lblPresent
            // 
            lblPresent.AutoSize = true;
            lblPresent.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPresent.ForeColor = Color.White;
            lblPresent.Location = new Point(13, 11);
            lblPresent.Name = "lblPresent";
            lblPresent.Size = new Size(145, 28);
            lblPresent.TabIndex = 0;
            lblPresent.Text = "Present Today";
            // 
            // panel5
            // 
            panel5.BackColor = Color.RoyalBlue;
            panel5.Controls.Add(lblTotalEmployeesCount);
            panel5.Controls.Add(lblTotalEmployeesTitle);
            panel5.Location = new Point(28, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(184, 118);
            panel5.TabIndex = 9;
            // 
            // lblTotalEmployeesCount
            // 
            lblTotalEmployeesCount.AutoSize = true;
            lblTotalEmployeesCount.BackColor = Color.RoyalBlue;
            lblTotalEmployeesCount.Font = new Font("Segoe UI Emoji", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTotalEmployeesCount.ForeColor = Color.White;
            lblTotalEmployeesCount.Location = new Point(34, 50);
            lblTotalEmployeesCount.Name = "lblTotalEmployeesCount";
            lblTotalEmployeesCount.Size = new Size(106, 37);
            lblTotalEmployeesCount.TabIndex = 1;
            lblTotalEmployeesCount.Text = "📅  50";
            // 
            // lblTotalEmployeesTitle
            // 
            lblTotalEmployeesTitle.AutoSize = true;
            lblTotalEmployeesTitle.BackColor = Color.RoyalBlue;
            lblTotalEmployeesTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTotalEmployeesTitle.ForeColor = Color.White;
            lblTotalEmployeesTitle.Location = new Point(9, 11);
            lblTotalEmployeesTitle.Name = "lblTotalEmployeesTitle";
            lblTotalEmployeesTitle.Size = new Size(166, 28);
            lblTotalEmployeesTitle.TabIndex = 0;
            lblTotalEmployeesTitle.Text = "Total Employees";
            // 
            // panel3
            // 
            panel3.BackColor = Color.White;
            panel3.Controls.Add(lblDate);
            panel3.Controls.Add(lnkViewAll);
            panel3.Controls.Add(dgvActivities);
            panel3.Controls.Add(label7);
            panel3.Controls.Add(label9);
            panel3.Controls.Add(panel4);
            panel3.Controls.Add(label4);
            panel3.Location = new Point(253, 68);
            panel3.Name = "panel3";
            panel3.Size = new Size(1051, 578);
            panel3.TabIndex = 4;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Location = new Point(733, 22);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(50, 20);
            lblDate.TabIndex = 8;
            lblDate.Text = "label8";
            // 
            // lnkViewAll
            // 
            lnkViewAll.AutoSize = true;
            lnkViewAll.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lnkViewAll.Location = new Point(538, 540);
            lnkViewAll.Name = "lnkViewAll";
            lnkViewAll.Size = new Size(180, 25);
            lnkViewAll.TabIndex = 7;
            lnkViewAll.TabStop = true;
            lnkViewAll.Text = "View All Activities...";
            lnkViewAll.LinkClicked += lnkViewAll_LinkClicked;
            // 
            // dgvActivities
            // 
            dgvActivities.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvActivities.Location = new Point(37, 275);
            dgvActivities.Name = "dgvActivities";
            dgvActivities.RowHeadersWidth = 51;
            dgvActivities.Size = new Size(746, 243);
            dgvActivities.TabIndex = 6;
            dgvActivities.CellContentClick += dgvActivities_CellContentClick;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(20, 217);
            label7.Name = "label7";
            label7.Size = new Size(183, 31);
            label7.TabIndex = 5;
            label7.Text = "Recent Activities";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(652, 15);
            label9.Name = "label9";
            label9.Size = new Size(62, 28);
            label9.TabIndex = 4;
            label9.Text = "Date :";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1299, 853);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(pnlmenu);
            Name = "Form1";
            Text = "Dashboard";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlmenu.ResumeLayout(false);
            pnlmenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel4.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvActivities).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel2;
        private PictureBox pictureBox1;
        private Label label1;
        private Button btnDashboard;
        private Button btnEmployees;
        private Button btnAttendance;
        private Button btnLeave;
        private Button btnPayroll;
        private Button btnDepartments;
        private Button btnReports;
        private Button btnSettings;
        private Panel pnlmenu;
        private Button btnNotification;
        private Label label2;
        private PictureBox pictureBox2;
        private Button btnLogout;
        private Panel panel1;
        private Label label4;
        private Panel panel4;
        private Panel panel7;
        private Label label20;
        private Label label19;
        private Panel panel8;
        private Panel panel6;
        private Label lblPresentCount;
        private Label lblPresent;
        private Panel panel5;
        private Label lblTotalEmployeesCount;
        private Label lblTotalEmployeesTitle;
        private Panel panel3;
        private Label label9;
        private Panel panel10;
        private Panel panel9;
        private Label lblMonth;
        private Label lblMonthPayroll;
        private Label label3;
        private Label label6;
        private Label label5;
        private Label label7;
        private DataGridView dgvActivities;
        private LinkLabel lnkViewAll;
        private Label lblDate;
    }
}
